<!DOCTYPE html>

<html lang="en">

  <head>

    <title>Employee Pagination with AJAX</title>

    <meta charset="utf-8">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css" />

    <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

    <style type="text/css">

      html, body { font-family: 'Raleway', sans-serif; }

      a{ color: #007bff; font-weight: bold;}

    </style>

  </head> 

  <body>

      

   <div class="container">

    <div class="card">

      <div class="card-header">

      Employee Pagination with AJAX

      </div>

      <div class="card-body">

           <!-- Posts List -->

           <table class="table table-borderd" id='postsList'>

             <thead>

              <tr>

                <th>S.no</th>

                <th>Name</th>

                <th>Designation</th>

              </tr>

             </thead>

             <tbody></tbody>

           </table>

           

           <!-- Paginate -->

           <div id='pagination'></div>

      </div>

    </div>

   </div>

 

   <!-- Script -->

   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

   <script type='text/javascript'>

   $(document).ready(function(){

     $('#pagination').on('click','a',function(e){

       e.preventDefault(); 

       var pageno = $(this).attr('data-ci-pagination-page');

       loadPagination(pageno);

     });

     loadPagination(0);

     function loadPagination(pagno){
       $.ajax({
         url: 'http://localhost/employee/index.php/post/loadRecord/'+pagno,
         type: 'GET',
         dataType: 'JSON',
         success: function(response){
        
            $('#pagination').html(response.pagination);
            createTable(response.result,response.row);
         }
       });

     }

     function createTable(result, sno){

       sno = Number(sno);

       $('#postsList tbody').empty();

       for(index in result){

          console.log(result[index].id);

          var id = result[index].id;

          var name = result[index].name;

          var designation = result[index].designation;

          sno+=1;

          var tr = "<tr>";

          tr += "<td>"+ sno +"</td>";

          tr += "<td>"+ name +"</td>";

          tr += "<td>"+ designation +"</td>";

          tr += "</tr>";

          $('#postsList tbody').append(tr);

        }
      }
    });

    </script>

  </body>

</html>